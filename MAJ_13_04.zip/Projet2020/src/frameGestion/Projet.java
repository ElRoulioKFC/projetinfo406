package frameGestion;

public class Projet {
	private String nomP;
	private int nbheure;
	
	public Projet(String nom, int nb) {
		this.nomP = nom;
		this.nbheure = nb;
	}
	
	
}
