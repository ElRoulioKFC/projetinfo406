package controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import frameGestion.*;

public class AjoutEmployesListener implements ActionListener{
	private Employes emp;
	

}
