package projet_info_v0;

public class Main {

	public static void main(String[] args) {

		new Projet(0,"nom");
		
	}

}
