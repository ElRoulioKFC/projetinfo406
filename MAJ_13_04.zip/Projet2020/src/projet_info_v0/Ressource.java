package projet_info_v0;

public class Ressource {
	
	

}
